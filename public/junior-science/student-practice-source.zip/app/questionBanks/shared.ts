export type RetrievalQuestion = {
  id: string;
  course: string;
  topic: string;
  phase: string;
  subtopic: string;
  type: string;
  difficulty: string;
  question: string;
  answer: string;
};

const TYPES = ["Recall", "Explain", "Apply", "Check a misconception"];
const DIFFICULTIES = ["Core", "Core", "Developing", "Developing", "Extension"];

function slug(value: string) {
  return value.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
}

export function makePhase(
  topic: string,
  phase: string,
  pairs: Array<[question: string, answer: string]>,
): RetrievalQuestion[] {
  return pairs.map(([question, answer], index) => ({
    id: `y7-${slug(topic)}-${slug(phase)}-${String(index + 1).padStart(2, "0")}`,
    course: "Year 7 Science",
    topic,
    phase,
    subtopic: phase.replace(/^\d+\s*[—-]\s*/, ""),
    type: TYPES[index % TYPES.length],
    difficulty: DIFFICULTIES[index % DIFFICULTIES.length],
    question,
    answer,
  }));
}

export function makeYear8Phase(
  topic: string,
  phase: string,
  pairs: Array<[question: string, answer: string]>,
): RetrievalQuestion[] {
  return pairs.map(([question, answer], index) => ({
    id: `y8-${slug(topic)}-${slug(phase)}-${String(index + 1).padStart(2, "0")}`,
    course: "Year 8 Science",
    topic,
    phase,
    subtopic: phase.replace(/^\d+\s*[—-]\s*/, ""),
    type: TYPES[index % TYPES.length],
    difficulty: DIFFICULTIES[index % DIFFICULTIES.length],
    question,
    answer,
  }));
}

export function makeYear9Phase(
  topic: string,
  phase: string,
  pairs: Array<[question: string, answer: string]>,
): RetrievalQuestion[] {
  return pairs.map(([question, answer], index) => ({
    id: `y9-${slug(topic)}-${slug(phase)}-${String(index + 1).padStart(2, "0")}`,
    course: "Year 9 Science",
    topic,
    phase,
    subtopic: phase.replace(/^\d+\s*[—-]\s*/, ""),
    type: TYPES[index % TYPES.length],
    difficulty: DIFFICULTIES[index % DIFFICULTIES.length],
    question,
    answer,
  }));
}

export function makeScientificPracticePhase(
  year: 7 | 8 | 9,
  phase: string,
  pairs: Array<[question: string, answer: string]>,
): RetrievalQuestion[] {
  return pairs.map(([question, answer], index) => ({
    id: `y${year}-scientific-practices-${slug(phase)}-${String(index + 1).padStart(2, "0")}`,
    course: `Year ${year} Science`,
    topic: "Scientific Practices",
    phase,
    subtopic: phase.replace(/^\d+\s*[—-]\s*/, ""),
    type: "Scientific practice",
    difficulty: DIFFICULTIES[index % DIFFICULTIES.length],
    question,
    answer,
  }));
}
