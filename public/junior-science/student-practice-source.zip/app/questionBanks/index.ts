import { cellularRespirationQuestions } from "./cellularRespiration";
import { deformationFrictionQuestions } from "./deformationFriction";
import { diffusionQuestions } from "./diffusion";
import { ecosystemInteractionQuestions } from "./ecosystemInteractions";
import { materialPropertyQuestions } from "./materialProperties";
import { photosynthesisQuestions } from "./photosynthesis";
import { rocksMineralsQuestions } from "./rocksMinerals";
import { statesOfMatterQuestions } from "./statesOfMatter";
import { thermalEnergyQuestions } from "./thermalEnergy";
export { scientificPracticeQuestions } from "./scientificPractices";
export { year8Questions } from "./year8";
export { year9Questions } from "./year9";

export const additionalYear7Questions = [
  ...cellularRespirationQuestions,
  ...deformationFrictionQuestions,
  ...diffusionQuestions,
  ...ecosystemInteractionQuestions,
  ...materialPropertyQuestions,
  ...photosynthesisQuestions,
  ...rocksMineralsQuestions,
  ...statesOfMatterQuestions,
  ...thermalEnergyQuestions,
];
