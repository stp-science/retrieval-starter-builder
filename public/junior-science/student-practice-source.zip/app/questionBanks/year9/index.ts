import { chemicalReactionsYear9Questions } from "./chemicalReactions";
import { ecosystemsYear9Questions } from "./ecosystems";
import { effectOfForcesYear9Questions } from "./effectOfForces";
import { elementsMoleculesCompoundsYear9Questions } from "./elementsMoleculesCompounds";
import { fluidsPressureYear9Questions } from "./fluidsPressure";
import { organismTraitsYear9Questions } from "./organismTraits";
import { periodicTableYear9Questions } from "./periodicTable";
import { spheresEarthYear9Questions } from "./spheresEarth";
import { transportHumansYear9Questions } from "./transportHumans";

export const year9Questions = [
  ...chemicalReactionsYear9Questions,
  ...ecosystemsYear9Questions,
  ...effectOfForcesYear9Questions,
  ...elementsMoleculesCompoundsYear9Questions,
  ...fluidsPressureYear9Questions,
  ...organismTraitsYear9Questions,
  ...periodicTableYear9Questions,
  ...spheresEarthYear9Questions,
  ...transportHumansYear9Questions,
];
