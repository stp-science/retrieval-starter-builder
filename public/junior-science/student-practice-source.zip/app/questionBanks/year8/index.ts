import { adaptationEvolutionQuestions } from "./adaptationEvolution";
import { chemicalChangeQuestions } from "./chemicalChange";
import { digestiveSystemQuestions } from "./digestiveSystem";
import { electricalChargeQuestions } from "./electricalCharge";
import { extraBodySystemQuestions } from "./extraBodySystems";
import { extraChemistryQuestions } from "./extraChemistry";
import { extraInheritanceReproductionQuestions } from "./extraInheritanceReproduction";
import { extraPhysicalQuestions } from "./extraPhysical";
import { gasExchangeQuestions } from "./gasExchange";
import { mixturesQuestions } from "./mixtures";
import { pressureQuestions } from "./pressure";
import { reproductionQuestions } from "./reproduction";
import { solubilityQuestions } from "./solubility";
import { universeQuestions } from "./universe";

export const year8Questions = [
  ...adaptationEvolutionQuestions,
  ...chemicalChangeQuestions,
  ...digestiveSystemQuestions,
  ...electricalChargeQuestions,
  ...gasExchangeQuestions,
  ...mixturesQuestions,
  ...pressureQuestions,
  ...reproductionQuestions,
  ...solubilityQuestions,
  ...universeQuestions,
  ...extraBodySystemQuestions,
  ...extraChemistryQuestions,
  ...extraInheritanceReproductionQuestions,
  ...extraPhysicalQuestions,
];
