import { makeYear8Phase, RetrievalQuestion } from "../shared";

export function makeYear8Extra(
  topic: string,
  phase: string,
  pairs: Array<[question: string, answer: string]>,
): RetrievalQuestion[] {
  return makeYear8Phase(topic, phase, pairs).map((question) => ({
    ...question,
    id: question.id.replace(/^y8-/, "y8-extra-"),
  }));
}
