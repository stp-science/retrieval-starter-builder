"use client";

import { useEffect, useMemo, useRef, useState } from "react";

type Question = {
  id: string;
  course: string;
  topic: string;
  phase: string;
  question: string;
  answer: string;
};

type Props = { questions: Question[] };

type LeitnerProgress = {
  box: number;
  nextDue: number;
  lastReviewed: number;
  attempts: number;
  correct: number;
};

type AnswerRating = "known" | "unknown";

const YEARS = ["Year 7", "Year 8", "Year 9", "Year 10"];
const PRACTICE_TOPIC = "Scientific Practices";
const LEITNER_STORAGE_KEY = "stp-junior-science-leitner-v1";
const THEME_STORAGE_KEY = "cells-retrieval-theme";
const DAY_IN_MS = 24 * 60 * 60 * 1000;
const BOX_INTERVAL_DAYS = [0, 1, 3, 7, 14, 30];
type QuizFocus = "knowledge" | "practices";

function readLocalStorage(key: string) {
  if (typeof window === "undefined") return null;

  try {
    return window.localStorage.getItem(key);
  } catch {
    return null;
  }
}

function writeLocalStorage(key: string, value: string) {
  try {
    window.localStorage.setItem(key, value);
  } catch {
    // Google Sites and privacy-focused browsers may restrict storage in embeds.
    // Keep the current session usable even when progress cannot be persisted.
  }
}

function removeLocalStorage(key: string) {
  try {
    window.localStorage.removeItem(key);
  } catch {
    // A restricted embed should never stop the retrieval controls from working.
  }
}

const CURRICULUM_TOPIC_ORDER: Record<string, string[]> = {
  "Year 7": [
    "Material Properties",
    "States of Matter and Particle Models",
    "Cells and Organisation",
    "Thermal Energy",
    "Diffusion",
    "Cellular Respiration",
    "Deformation and Friction",
    "Photosynthesis",
    "Ecosystem Interactions",
    "Rocks and Minerals",
  ],
  "Year 8": [
    "Mixtures, Solutions and Concentration",
    "Solubility",
    "Reproductive Structures and Processes",
    "Electrical Charge and Static Electricity",
    "Chemical Change",
    "Digestive System",
    "Gas Exchange",
    "Pressure",
    "Adaptation and Evolution",
    "The Universe: Stars and Planets",
  ],
  "Year 9": [
    "Elements, Molecules and Compounds",
    "Periodic Table",
    "Determining Organism Traits",
    "Chemical Reactions",
    "The Effect of Forces",
    "Fluids and Pressure",
    "Transport Systems in Humans",
    "Spheres of the Earth",
    "Ecosystems",
  ],
};

function yearFromCourse(course: string) {
  return YEARS.find((year) => course.includes(year)) ?? course;
}

function sortTopicsByCurriculum(year: string, topics: string[]) {
  const curriculumOrder = CURRICULUM_TOPIC_ORDER[year] ?? [];
  const orderIndex = new Map(curriculumOrder.map((topic, index) => [topic, index]));

  return [...topics].sort((a, b) => {
    const aIndex = orderIndex.get(a) ?? Number.MAX_SAFE_INTEGER;
    const bIndex = orderIndex.get(b) ?? Number.MAX_SAFE_INTEGER;
    return aIndex - bIndex || a.localeCompare(b);
  });
}

function dailyScore(id: string, key: string) {
  let value = 2166136261;
  for (const character of `${key}-${id}`) {
    value = Math.imul(value ^ character.charCodeAt(0), 16777619);
  }
  return value >>> 0;
}

function readStoredProgress(validQuestionIds: Set<string>) {
  if (typeof window === "undefined") return {};

  try {
    const raw = readLocalStorage(LEITNER_STORAGE_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw) as { questions?: Record<string, LeitnerProgress> };
    const savedQuestions = parsed.questions ?? {};

    return Object.fromEntries(Object.entries(savedQuestions).filter(([id, item]) =>
      validQuestionIds.has(id) &&
      Number.isFinite(item?.box) &&
      Number.isFinite(item?.nextDue) &&
      Number.isFinite(item?.lastReviewed) &&
      Number.isFinite(item?.attempts) &&
      Number.isFinite(item?.correct)
    ));
  } catch {
    return {};
  }
}

function saveProgress(progress: Record<string, LeitnerProgress>) {
  writeLocalStorage(LEITNER_STORAGE_KEY, JSON.stringify({
    version: 1,
    questions: progress,
  }));
}

function compareByLeitnerPriority(
  a: Question,
  b: Question,
  progress: Record<string, LeitnerProgress>,
  now: number,
  key: string,
) {
  const aProgress = progress[a.id];
  const bProgress = progress[b.id];

  function priority(item?: LeitnerProgress) {
    if (item?.box === 0) return 0;
    if (item && item.nextDue <= now) return 1;
    if (!item) return 2;
    return 3;
  }

  const priorityDifference = priority(aProgress) - priority(bProgress);
  if (priorityDifference) return priorityDifference;

  if (aProgress && bProgress) {
    const dueDifference = aProgress.nextDue - bProgress.nextDue;
    if (dueDifference) return dueDifference;
  }

  return dailyScore(a.id, key) - dailyScore(b.id, key);
}

export default function RetrievalTool({ questions }: Props) {
  const [year, setYear] = useState("Year 7");
  const [focus, setFocus] = useState<QuizFocus>("knowledge");
  const [selectedTopics, setSelectedTopics] = useState<string[]>(["Material Properties"]);
  const [phase, setPhase] = useState("all");
  const [quizKey, setQuizKey] = useState(() => new Date().toLocaleDateString("en-NZ", { timeZone: "Pacific/Auckland" }));
  const [questionIndex, setQuestionIndex] = useState(0);
  const [answerVisible, setAnswerVisible] = useState(false);
  const [dark, setDark] = useState(false);
  const [progress, setProgress] = useState<Record<string, LeitnerProgress>>({});
  const [ratings, setRatings] = useState<Record<string, AnswerRating>>({});
  const progressRef = useRef<Record<string, LeitnerProgress>>({});
  const ratingBaselinesRef = useRef<Record<string, LeitnerProgress | null>>({});
  const validQuestionIds = useMemo(() => new Set(questions.map((item) => item.id)), [questions]);

  useEffect(() => {
    const storedProgress = readStoredProgress(validQuestionIds);
    progressRef.current = storedProgress;
    setProgress(storedProgress);
    setDark(readLocalStorage(THEME_STORAGE_KEY) === "dark");
    setQuizKey((current) => `${current}-saved-progress`);
  }, [validQuestionIds]);

  const topics = useMemo(() => sortTopicsByCurriculum(year, [...new Set(questions.filter((item) =>
    yearFromCourse(item.course) === year &&
    (focus === "practices" ? item.topic === PRACTICE_TOPIC : item.topic !== PRACTICE_TOPIC)
  ).map((item) => item.topic))]), [focus, questions, year]);

  const phases = useMemo(
    () => selectedTopics.length === 1
      ? [...new Set(questions.filter(
        (item) => yearFromCourse(item.course) === year && item.topic === selectedTopics[0],
      ).map((item) => item.phase))]
      : [],
    [questions, selectedTopics, year],
  );

  const quiz = useMemo(() => {
    if (!selectedTopics.length) return [];
    const selectionKey = [...selectedTopics].sort().join("|");
    const key = `${quizKey}-${year}-${selectionKey}-${phase}`;
    const now = Date.now();
    const topicOrder = [...selectedTopics].sort(
      (a, b) => dailyScore(a, key) - dailyScore(b, key),
    );
    const pools = new Map(topicOrder.map((selectedTopic) => [
      selectedTopic,
      questions
        .filter((item) =>
          yearFromCourse(item.course) === year &&
          item.topic === selectedTopic &&
          (selectedTopics.length > 1 || phase === "all" || item.phase === phase)
        )
        .sort((a, b) => compareByLeitnerPriority(a, b, progressRef.current, now, key)),
    ]));

    const balancedQuiz: Question[] = [];
    let round = 0;
    while (balancedQuiz.length < 10) {
      let added = false;
      for (const selectedTopic of topicOrder) {
        const candidate = pools.get(selectedTopic)?.[round];
        if (candidate) {
          balancedQuiz.push(candidate);
          added = true;
          if (balancedQuiz.length === 10) break;
        }
      }
      if (!added) break;
      round += 1;
    }
    return balancedQuiz;
  }, [phase, questions, quizKey, selectedTopics, year]);

  function resetQuiz() {
    setPhase("all");
    setQuestionIndex(0);
    setAnswerVisible(false);
    setRatings({});
    ratingBaselinesRef.current = {};
  }

  function choosePhase(nextPhase: string) {
    setPhase(nextPhase);
    setQuestionIndex(0);
    setAnswerVisible(false);
    setRatings({});
    ratingBaselinesRef.current = {};
  }

  function chooseYear(nextYear: string) {
    const nextTopics = sortTopicsByCurriculum(nextYear, [...new Set(questions.filter((item) =>
      yearFromCourse(item.course) === nextYear &&
      (focus === "practices" ? item.topic === PRACTICE_TOPIC : item.topic !== PRACTICE_TOPIC)
    ).map((item) => item.topic))]);
    setYear(nextYear);
    setSelectedTopics(nextTopics.length ? [nextTopics[0]] : []);
    resetQuiz();
  }

  function chooseFocus(nextFocus: QuizFocus) {
    const nextTopics = sortTopicsByCurriculum(year, [...new Set(questions.filter((item) =>
      yearFromCourse(item.course) === year &&
      (nextFocus === "practices" ? item.topic === PRACTICE_TOPIC : item.topic !== PRACTICE_TOPIC)
    ).map((item) => item.topic))]);
    setFocus(nextFocus);
    setSelectedTopics(nextTopics.length ? [nextTopics[0]] : []);
    resetQuiz();
  }

  function toggleTopic(topic: string) {
    setSelectedTopics((current) =>
      current.includes(topic)
        ? current.filter((item) => item !== topic)
        : [...current, topic],
    );
    resetQuiz();
  }

  function toggleAllTopics() {
    setSelectedTopics(selectedTopics.length === topics.length ? [] : topics);
    resetQuiz();
  }

  function move(direction: number) {
    setQuestionIndex((current) => Math.max(0, Math.min(current + direction, quiz.length - 1)));
    setAnswerVisible(false);
  }

  function newRandomQuiz() {
    setQuizKey(`${Date.now()}`);
    setQuestionIndex(0);
    setAnswerVisible(false);
    setRatings({});
    ratingBaselinesRef.current = {};
  }

  function toggleTheme() {
    setDark((current) => {
      const next = !current;
      writeLocalStorage(THEME_STORAGE_KEY, next ? "dark" : "light");
      return next;
    });
  }

  function rateAnswer(questionId: string, rating: AnswerRating) {
    if (!Object.prototype.hasOwnProperty.call(ratingBaselinesRef.current, questionId)) {
      ratingBaselinesRef.current[questionId] = progressRef.current[questionId]
        ? { ...progressRef.current[questionId] }
        : null;
    }

    const baseline = ratingBaselinesRef.current[questionId];
    const now = Date.now();
    const previousBox = baseline?.box ?? 0;
    const nextBox = rating === "known"
      ? Math.min(Math.max(previousBox + 1, 1), BOX_INTERVAL_DAYS.length - 1)
      : 0;
    const nextProgress: LeitnerProgress = {
      box: nextBox,
      nextDue: now + BOX_INTERVAL_DAYS[nextBox] * DAY_IN_MS,
      lastReviewed: now,
      attempts: (baseline?.attempts ?? 0) + 1,
      correct: (baseline?.correct ?? 0) + (rating === "known" ? 1 : 0),
    };
    const updatedProgress = {
      ...progressRef.current,
      [questionId]: nextProgress,
    };

    progressRef.current = updatedProgress;
    setProgress(updatedProgress);
    setRatings((currentRatings) => ({ ...currentRatings, [questionId]: rating }));
    saveProgress(updatedProgress);
  }

  function resetSavedProgress() {
    if (!window.confirm("Reset all saved question progress on this device?")) return;
    removeLocalStorage(LEITNER_STORAGE_KEY);
    progressRef.current = {};
    ratingBaselinesRef.current = {};
    setProgress({});
    setRatings({});
    setQuestionIndex(0);
    setAnswerVisible(false);
    setQuizKey(`${Date.now()}-reset`);
  }

  const progressSummary = useMemo(() => {
    const saved = Object.entries(progress).filter(([id]) => validQuestionIds.has(id));
    const now = Date.now();
    return {
      reviewed: saved.length,
      known: saved.filter(([, item]) => item.box > 0).length,
      needsPractice: saved.filter(([, item]) => item.box === 0).length,
      due: saved.filter(([, item]) => item.nextDue <= now).length,
    };
  }, [progress, validQuestionIds]);

  const current = quiz[questionIndex];
  const multipleTopics = selectedTopics.length > 1;
  const topicSummary = selectedTopics.length === 1
    ? selectedTopics[0]
    : `${selectedTopics.length} topics selected`;
  const currentRating = current ? ratings[current.id] : undefined;
  const currentProgress = current ? progress[current.id] : undefined;
  const nextIntervalDays = currentProgress ? BOX_INTERVAL_DAYS[currentProgress.box] : 0;

  return (
    <main className={`app-frame${dark ? " dark" : ""}`}>
      <div className="site-shell">
        <header className="topbar">
          <div className="brand-mark" aria-hidden="true">JS</div>
          <div>
            <p className="eyebrow">St Peter&apos;s School</p>
            <h1>Junior Science Retrieval Practice</h1>
          </div>
          <button className="theme-button" type="button" aria-label={dark ? "Use light theme" : "Use dark theme"} onClick={toggleTheme}>
            {dark ? "☀" : "☾"}
          </button>
        </header>

        <section className="hero compact-hero" aria-labelledby="tool-heading">
          <div>
            <p className="eyebrow accent">Daily retrieval quiz</p>
            <h2 id="tool-heading">Ten questions. Every day.</h2>
            <p>Practise topic knowledge, combine topics, or build your scientific-practice skills.</p>
          </div>
        </section>

        <section className="simple-controls" aria-label="Choose a quiz">
          <label>
            Year group
            <select value={year} onChange={(event) => chooseYear(event.target.value)}>
              {YEARS.map((item) => <option value={item} key={item}>{item}</option>)}
            </select>
          </label>
          <label>
            Quiz focus
            <select value={focus} onChange={(event) => chooseFocus(event.target.value as QuizFocus)}>
              <option value="knowledge">Topic knowledge</option>
              <option value="practices">Scientific practices</option>
            </select>
          </label>
          <label>
            {focus === "practices" ? "Practice area" : "Learning phase"}
            <select value={phase} disabled={selectedTopics.length !== 1 || !phases.length} onChange={(event) => choosePhase(event.target.value)}>
              <option value="all">{focus === "practices" ? "All scientific practices" : multipleTopics ? "Whole selected topics" : "Whole topic revision"}</option>
              {phases.map((item) => <option value={item} key={item}>{item}</option>)}
            </select>
            {multipleTopics && <span className="control-note">Learning phases apply when one topic is selected.</span>}
          </label>
          <button className="primary-button" type="button" onClick={newRandomQuiz} disabled={!quiz.length}>Make a new random quiz</button>

          {focus === "knowledge" ? <fieldset className="topic-picker">
            <legend>Topics</legend>
            <button type="button" className="select-all-button" onClick={toggleAllTopics} disabled={!topics.length}>
              {selectedTopics.length === topics.length ? "Clear all" : "Select all"}
            </button>
            {topics.length ? (
              <div className="topic-options">
                {topics.map((item) => (
                  <label className="topic-option" key={item}>
                    <input
                      type="checkbox"
                      checked={selectedTopics.includes(item)}
                      onChange={() => toggleTopic(item)}
                    />
                    <span>{item}</span>
                  </label>
                ))}
              </div>
            ) : <p className="topics-coming-soon">Topics coming soon</p>}
            <p className="topic-count" aria-live="polite">
              {selectedTopics.length} of {topics.length} topics selected
            </p>
          </fieldset> : (
            <div className="practice-focus-note">
              <strong>Scientific practices</strong>
              <span>Choose one practice area above, or select all scientific practices for a mixed skills quiz.</span>
            </div>
          )}
        </section>

        <section className="learning-summary" aria-label="Saved retrieval progress">
          <div className="learning-summary-intro">
            <strong>Spaced practice on this device</strong>
            <span>Questions you miss return sooner. Questions you know are spaced out over time.</span>
          </div>
          <dl>
            <div><dt>Reviewed</dt><dd>{progressSummary.reviewed}</dd></div>
            <div><dt>Known</dt><dd>{progressSummary.known}</dd></div>
            <div><dt>Needs practice</dt><dd>{progressSummary.needsPractice}</dd></div>
            <div><dt>Due now</dt><dd>{progressSummary.due}</dd></div>
          </dl>
          <button className="reset-progress-button" type="button" onClick={resetSavedProgress} disabled={!progressSummary.reviewed}>
            Reset progress
          </button>
        </section>

        {current ? (
          <section className="quiz-stage" aria-live="polite">
            <div className="quiz-status">
              <span>Question {questionIndex + 1} of {quiz.length}</span>
              <span>{year} · {focus === "practices" ? "Scientific practices" : topicSummary} · {multipleTopics ? "Mixed revision" : phase === "all" ? focus === "practices" ? "All practice areas" : "Whole topic" : phase}</span>
            </div>
            <div className="progress-track" aria-hidden="true"><span style={{ width: `${((questionIndex + 1) / quiz.length) * 100}%` }} /></div>

            <article className={`daily-question${answerVisible ? " answer-shown" : ""}`}>
              <p className="question-kicker">{answerVisible ? "Answer" : `Question ${questionIndex + 1}`} · {current.topic}</p>
              <h3>{answerVisible ? current.answer : current.question}</h3>
              <button className="reveal-button" type="button" onClick={() => setAnswerVisible((visible) => !visible)}>
                {answerVisible ? "Show question" : "Reveal answer"}
              </button>
              {answerVisible && (
                <div className="self-mark" aria-label="Self-mark this answer">
                  <p>Did you know the answer before revealing it?</p>
                  <div className="rating-buttons">
                    <button
                      className={`rating-button known${currentRating === "known" ? " selected" : ""}`}
                      type="button"
                      aria-pressed={currentRating === "known"}
                      onClick={() => rateAnswer(current.id, "known")}
                    >
                      I know the answer
                    </button>
                    <button
                      className={`rating-button unknown${currentRating === "unknown" ? " selected" : ""}`}
                      type="button"
                      aria-pressed={currentRating === "unknown"}
                      onClick={() => rateAnswer(current.id, "unknown")}
                    >
                      I don&apos;t know it
                    </button>
                  </div>
                  {currentRating && (
                    <p className="rating-confirmation" role="status">
                      {currentRating === "unknown"
                        ? "Saved. This question will be prioritised in your next quiz."
                        : `Saved. This question will return in ${nextIntervalDays === 1 ? "1 day" : `${nextIntervalDays} days`}.`}
                    </p>
                  )}
                </div>
              )}
            </article>

            <div className="quiz-navigation">
              <button className="text-button" type="button" onClick={() => move(-1)} disabled={questionIndex === 0}>Previous</button>
              <button className="primary-button" type="button" onClick={() => move(1)} disabled={questionIndex === quiz.length - 1}>Next question</button>
            </div>
          </section>
        ) : (
          <div className="empty-state">
            <h3>{topics.length ? "Choose at least one topic." : `${year} topics are coming soon.`}</h3>
            <p>{topics.length ? "Tick any topic above to build a 10-question quiz." : "Choose Year 7 to use the available retrieval quizzes."}</p>
          </div>
        )}

        <footer>
          <p>St Peter&apos;s School Junior Science Retrieval Practice</p>
          <p>Retrieve first. Check second. Repeat tomorrow.</p>
        </footer>
      </div>
    </main>
  );
}
