import RetrievalTool from "./RetrievalTool";
import questions from "./questions.json";
import { additionalYear7Questions, scientificPracticeQuestions, year8Questions, year9Questions } from "./questionBanks";

export default function Home() {
  return <RetrievalTool questions={[...questions, ...additionalYear7Questions, ...year8Questions, ...year9Questions, ...scientificPracticeQuestions]} />;
}
